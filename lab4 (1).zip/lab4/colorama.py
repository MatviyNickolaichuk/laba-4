from colorama import Fore, init

init(autoreset=True)

def colored_print(text, color=Fore.GREEN):
    print(color + text)
