from datetime import datetime
from dateutil.relativedelta import relativedelta

def add_months(months=3):
    return datetime.now() + relativedelta(months=months)
