from faker import Faker

def fake_people(n=3):
    fake = Faker("uk_UA")
    return [(fake.name(), fake.address().replace("\n", ", ")) for _ in range(n)]
