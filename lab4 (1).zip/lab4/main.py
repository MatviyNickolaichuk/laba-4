from f01_requests import get_status
from f02_numpy import matrix_stats
from f03_pandas import make_dataframe
from f04_colorama import colored_print
from f05_rich import show_table
from f06_tqdm import progress
from f07_pyfiglet import banner
from f08_dateutil import add_months
from f09_faker import fake_people
from f10_matplotlib import save_plot
from f11_os import list_files
from f12_json import save_json
from f13_random import random_numbers
from f14_datetime import now_str
from f15_math import circle_area


def main():
    print(banner("Lab 4"))
    colored_print("Час зараз: " + now_str())
    print("Статус google:", get_status("https://google.com"))

    m, s, mean, det = matrix_stats()
    print("Матриця:\n", m, "\nСума:", s, "Середнє:", mean, "Det:", round(det, 2))

    people = fake_people()
    show_table(people)
    df = make_dataframe({"name": [p[0] for p in people], "addr": [p[1] for p in people]})
    print(df)

    nums = random_numbers()
    print("Числа:", nums)
    print("Графік:", save_plot(range(len(nums)), nums))
    print("Площа кола r=5:", round(circle_area(5), 2))
    print("Через 3 місяці:", add_months(3).strftime("%d.%m.%Y"))
    print("Файли:", list_files())
    print("Збережено:", save_json({"numbers": nums, "people": people}))
    progress()


if __name__ == "__main__":
    main()
