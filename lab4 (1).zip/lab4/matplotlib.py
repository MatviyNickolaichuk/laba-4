import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

def save_plot(xs, ys, filename="plot.png"):
    plt.figure()
    plt.plot(xs, ys, marker="o")
    plt.title("Графік")
    plt.savefig(filename)
    plt.close()
    return filename
