import numpy as np

def matrix_stats(n=3):
    m = np.random.randint(1, 10, (n, n))
    return m, m.sum(), m.mean(), np.linalg.det(m)
