import pandas as pd

def make_dataframe(data):
    return pd.DataFrame(data)
