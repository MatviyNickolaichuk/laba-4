from rich.console import Console
from rich.table import Table

def show_table(rows):
    t = Table(title="Люди")
    t.add_column("Ім'я")
    t.add_column("Адреса")
    for name, addr in rows:
        t.add_row(name, addr)
    Console().print(t)
